// let x=10;
// function fun(){
//     let y=5;
//     console.log(y);

// }
// fun();
// console.log(x);


function fun(){
    console.log("fun");
    function inside(){
        console.log("inside");
    }
    return inside;
}
var insidefun=fun();
insidefun();











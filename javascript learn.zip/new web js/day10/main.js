// let a = 10;
// let b = 20;
// function fun(){
//     console.log(a,b);

// }
// fun();
// let a=10;
// let a=20;
// console.log(a);

// var a= 10;
// var a=20;
// console.log(a)

// let a =10;
// {
//     let a=20
//     console.log(a)
// }

// console.log(a)

// var a=10;
// {
//     var a=15;
//     console.log(a)
// }
// console.log(a)
const a=[10];
a.push(20);
console.log(a)










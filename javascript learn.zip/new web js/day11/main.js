

// function fun2(){
//     console.log("World")
// }

// function fun(fun2){
//     console.log("hello");
//     fun2();
// }
// fun(fun2)


//callback function

// let arr=[1,2,3,4,5,6,7,8,9,10];
// console.log(arr)
// for(let i=0;i<arr;i++){
//     arr[i]=arr[i]*arr[i];
// }
// console.log(arr);


// function square(num1){
//     return num1*num1
// }
// // console.log(square(11))


//  let arr=[1,2,3,4,5,6,7,8,9,10];
// console.log(arr)
// let newarr=arr.map(square);
// console.log(newarr);
// console.log(arr)


//cube 

// let arr=[1,2,3,4,5,6,7,8,9,10];
// console.log("Number is ", arr)
// function cube(num1){
//    return num1*num1*num1
// }
// let newarray= arr.map(cube)
// console.log("cube of Numbers",newarray)


//sqrt
// let arr=[1,2,3,4,5,6,7,8,9,10];
// var newarray= arr.map(function (num1){
//     return parseInt(Math.sqrt(num1));
// })
// console.log(newarray);
// console.log(arr)


//filter

// var arr=[1,2,3,4,5,6,7,8,9,10];
// function isodd(num){
//     return num%2;
// }

// function iseven(num){
//     return !(num%2)
// }

// console.log(isodd(4))
// console.log(iseven(5))

// let newarr=arr.filter(isodd);
// console.log(newarr)

// let newarr2=arr.filter(iseven);
// console.log(newarr2)

let num = [20, 40, 90, -50, 20, -70, 80];
console.log(num.sort());









let a = [1, 2, 4, 5];
// Array.prototype.pop=function(){
//     console.log("I will not pop\n");
// }


// let obj1={
//     Name:"Reyaz Ahamad",
//     Age:19
// }
// let obj2=Object.create(obj1);           //creating dummy of obj1
// console.log(obj1);
// console.log(obj2);


// function fun(){
//     console.log(this);
// }
// fun();


// function aaaa() {
//     return 1;
// }

// function outer() {
//     console.log(this);
//     function inner() {
//         console.log(this);
//     }
//     return inner;
// }
// let b = outer();
// b();


function person(){
    this.name="Reyaz Ahamad",
    this.age=19;
    console.log(this){
        return
    }
}





























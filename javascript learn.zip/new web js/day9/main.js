// function fun() {
//     console.log("Fun");
//     function inside() {
//         console.log("This is inside");

//     }
//     return inside;
// }
// let b= fun()
// // console.log(b)

// b();

// function outside(){
//     console.log("Outside");
// }
// function fun(another){
//     console.log("fun");
//     another();
// }
// fun(outside);

function num1() {
    console.log("1");
}
function num2() {
    console.log("2");
}
function num3(fun2) {
    console.log("3");
    fun2();
}
function main(fun1, fun3) {
    console.log("main");
    fun3();
    fun1();

}
main(num1, num2);










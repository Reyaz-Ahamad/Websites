// //str.toLowerCase()

// let str="This is first program"
// undefined
// str.toUpperCase()
// 'THIS IS FIRST PROGRAM'

// str.toLowerCase()
// 'this is first program'


// undefined
// let str= "         this is space       "
// undefined
// str.trim()
// 'this is space'
// let a="This is a trm function"
// a.substr()
// 'This is a trm function'
// let a="This is a trm function"
// a.substr(5)
// 'is a trm function'
// a[4]
// ' '
// a[3]
// 's'
// a.substr(3,5)
// 's is '
// a.substr(5,10)
// 'is a trm f'
// a.indexOf("f")
// 14
// a
// 'This is a trm function'
// a.indexOf("i",4)
// 5
// a.replace("i","o");
// 'Thos is a trm function'
// a.replaceAll("i","o")
// 'Thos os a trm functoon'
// a
// 'This is a trm function'
// let change=a.substr(5,10)
// undefined
// a
// 'This is a trm function'
// change
// 'is a trm f' 
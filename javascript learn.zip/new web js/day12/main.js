//increasing order
// it sorts in  <br>
//         lecciographical order / dictionary order <br>
//         like(11111, 22222, 3333)

// let num=[1,2,44,66,9,5,3,22,1,0,86]
// console.log(num.sort())

//original sorting increasing order
// let num = [1, 2, 44, 66, 9, 5, 3, 22, 1, 0, 86]
// function compare(a, b) {
//     return a - b;
// }
// console.log(num)
// num.sort(compare)
// console.log(num)     

// decresing order
// let num = [1, 2, 44, 66, 9, 5, 3, 22, 1, 0, 86]
// function compare(a, b) {
//     return b - a;
// }
// console.log(num)
// num.sort(compare)
// console.log(num)


//filter mathod

let menu = ["Chhole Bhature", "Butter Chicken", "Rajma Chawal",
    "Chicken Biryani", "Dal Makhni", "Kadhai Paneer", "Garlic Bread",
    "onion rings", "Amritsari Naan", "Paav Bhaaji", "Ras Malai",
    "Onion Pizza", "Egg Curry", "Egg Omlet", "Garlic Naan", "Garlic Rice",
    "kadhai paneer", "Shahi Paneer", "Chai", "Momos", "Chicken Korma", "Dosa",
    "Uttapam", "Sambhar", "Vada Paav"];

let veg = menu.filter(function (dish) {
    if (dish.toLowerCase().indexOf("chicken") == -1 && dish.toLowerCase().indexOf("egg") == -1) {
        return false;
    }
    else {
        return true;
    }
})

console.log(veg);




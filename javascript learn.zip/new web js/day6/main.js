// function fun(){
// console.log("Hello world");

// }
// console.log(fun);
// console.log(math);


//function paramaeter
// function fun(x,y){
//     console.log(x+y)
// }
// fun(2,5)


//default parameter
// function fun(x,y,z=2){
//     console.log(x+y/z);
// }
// fun(20,5,5);

// function fun(){
//     var b=10;
//     console.log(b)

// }
//  fun();
//  console.log(b)



// let age = parseInt(prompt("Enter your age\n"));
// function vote(age){
//     if(age < 18){
//         console.log("You can'vote\n");
//     }
//     else if(age > 18 && age < 21){
//         console.log("You can give vote only\n");
//     }
//     else if(age > 21 && age < 100){
//         console.log("You can vote and drink\n");
//     }
//     else{
//         console.log("invalide age\n");
//     }
// }
// vote();


function getIndex(str,ch,ind){
    let count=0;
    let i=0;
    for(;i<str.length;i++){
        
        if(str[i]==ch){
            count++ 
        }
        if(count==ind){
            break;
        }


    }
    console.log(i)
    
}
(getIndex("abiiooooixzziklmimoo","i",4));

















